import { ReactNode, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  MessageSquare,
  Calendar,
  Settings,
  LogOut,
  Menu,
  Package,
  ChevronDown,
  Phone,
  Share2,
  Search,
  Building2
} from 'lucide-react';
import { useAuthStore } from '../store/auth';
import { cn } from '../lib/utils';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  {
    name: 'Social Media',
    href: '/social',
    icon: Share2,
    children: [
      { name: 'Post Manager', href: '/social' },
      { name: 'Schedule Posts', href: '/social?tab=schedule' },
      { name: 'Analytics', href: '/social?tab=analytics' },
      { name: 'Account Settings', href: '/social?tab=settings' },
    ],
  },
  {
    name: 'WhatsApp',
    href: '/whatsapp',
    icon: Phone,
    children: [
      { name: 'Bulk Messaging', href: '/whatsapp' },
      { name: 'Group Extractor', href: '/whatsapp?tab=groups' },
      { name: 'AI Assistant', href: '/whatsapp?tab=ai' },
      { name: 'Account Settings', href: '/whatsapp?tab=settings' },
    ],
  },
  {
    name: 'Google Marketing',
    href: '/google',
    icon: Search,
    children: [
      { name: 'SEO Analysis', href: '/google' },
      { name: 'Business Profile', href: '/google?tab=business' },
      { name: 'Analytics', href: '/google?tab=analytics' },
      { name: 'Account Settings', href: '/google?tab=settings' },
    ],
  },
  {
    name: 'Modules',
    href: '/modules',
    icon: Package,
    children: [
      { name: 'Installed Modules', href: '/modules' },
      { name: 'Browse Modules', href: '/modules/browse' },
      { name: 'Updates', href: '/modules/updates' },
    ],
  },
  {
    name: 'Settings',
    href: '/settings',
    icon: Settings,
    children: [
      { name: 'General', href: '/settings' },
      { name: 'Account', href: '/settings/account' },
      { name: 'Integrations', href: '/settings/integrations' },
      { name: 'Billing', href: '/settings/billing' },
    ],
  },
];

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const setUser = useAuthStore((state) => state.setUser);
  const user = useAuthStore((state) => state.user);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);

  const handleLogout = () => {
    setUser(null);
    navigate('/login');
  };

  const toggleExpanded = (name: string) => {
    setExpandedItems((current) =>
      current.includes(name)
        ? current.filter((item) => item !== name)
        : [...current, name]
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="hidden md:fixed md:inset-y-0 md:flex md:w-64 md:flex-col">
        <div className="flex flex-grow flex-col overflow-y-auto border-r border-gray-200 bg-white pt-5">
          <div className="flex flex-shrink-0 items-center px-4">
            <MessageSquare className="h-8 w-8 text-blue-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">SocialHub</span>
          </div>
          <div className="mt-5 flex flex-grow flex-col">
            <nav className="flex-1 space-y-1 px-2 pb-4">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname.startsWith(item.href);
                const isExpanded = expandedItems.includes(item.name);

                return (
                  <div key={item.name}>
                    <button
                      onClick={() => {
                        if (item.children) {
                          toggleExpanded(item.name);
                        } else {
                          navigate(item.href);
                        }
                      }}
                      className={cn(
                        "group w-full flex items-center rounded-md px-2 py-2 text-sm font-medium",
                        isActive
                          ? "bg-gray-100 text-gray-900"
                          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                      )}
                    >
                      <Icon className="mr-3 h-6 w-6 flex-shrink-0 text-gray-400 group-hover:text-gray-500" />
                      <span className="flex-1">{item.name}</span>
                      {item.children && (
                        <ChevronDown
                          className={cn(
                            "ml-3 h-5 w-5 transform transition-transform duration-150",
                            isExpanded ? "rotate-180" : ""
                          )}
                        />
                      )}
                    </button>
                    {item.children && isExpanded && (
                      <div className="ml-8 mt-1 space-y-1">
                        {item.children.map((child) => (
                          <Link
                            key={child.href}
                            to={child.href}
                            className={cn(
                              "group flex items-center rounded-md px-2 py-2 text-sm font-medium",
                              location.pathname === child.href
                                ? "bg-gray-100 text-gray-900"
                                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                            )}
                          >
                            {child.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </nav>
          </div>
        </div>
      </div>
      <div className="flex flex-1 flex-col md:pl-64">
        <div className="sticky top-0 z-10 flex h-16 flex-shrink-0 bg-white shadow">
          <button
            type="button"
            className="border-r border-gray-200 px-4 text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500 md:hidden"
          >
            <span className="sr-only">Open sidebar</span>
            <Menu className="h-6 w-6" />
          </button>
          <div className="flex flex-1 justify-between px-4">
            <div className="flex flex-1"></div>
            <div className="ml-4 flex items-center md:ml-6">
              <div className="flex items-center gap-4">
                <div className="text-sm text-gray-700">
                  Welcome, {user?.name}
                </div>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="rounded-full bg-white p-1 text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  <span className="sr-only">Log out</span>
                  <LogOut className="h-6 w-6" />
                </button>
              </div>
            </div>
          </div>
        </div>
        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}