import { useState } from 'react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { useGoogleStore } from '../../lib/google/store';
import { Search, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import type { SEOReport, SEOIssue } from '../../lib/google/types';

export function SEOAnalyzer() {
  const [url, setUrl] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const addSEOReport = useGoogleStore((state) => state.addSEOReport);

  const handleAnalyze = async () => {
    setAnalyzing(true);
    
    // Simulate SEO analysis
    setTimeout(() => {
      const mockReport: SEOReport = {
        id: crypto.randomUUID(),
        url,
        score: 85,
        lastUpdated: new Date().toISOString(),
        issues: [
          {
            type: 'warning',
            message: 'Missing meta description',
            priority: 'high',
            recommendation: 'Add a descriptive meta description tag',
          },
          {
            type: 'error',
            message: 'Slow page load time',
            priority: 'high',
            recommendation: 'Optimize images and minimize JavaScript',
          },
          {
            type: 'info',
            message: 'No structured data found',
            priority: 'medium',
            recommendation: 'Implement Schema.org markup for better visibility',
          },
        ],
      };

      addSEOReport(mockReport);
      setAnalyzing(false);
      setUrl('');
    }, 2000);
  };

  const IssueIcon = ({ type }: { type: SEOIssue['type'] }) => {
    switch (type) {
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'info':
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const reports = useGoogleStore((state) => state.seoReports);

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">SEO Analyzer</h2>
        
        <div className="flex space-x-4">
          <Input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter URL to analyze"
            className="flex-1"
          />
          <Button
            onClick={handleAnalyze}
            disabled={!url || analyzing}
            className="min-w-[120px]"
          >
            {analyzing ? (
              'Analyzing...'
            ) : (
              <>
                <Search className="w-4 h-4 mr-2" />
                Analyze
              </>
            )}
          </Button>
        </div>
      </div>

      {reports.map((report) => (
        <div key={report.id} className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-medium text-gray-900">{report.url}</h3>
              <p className="text-sm text-gray-500">
                Last updated: {new Date(report.lastUpdated).toLocaleString()}
              </p>
            </div>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-blue-600">{report.score}</span>
              <span className="text-gray-500 ml-1">/100</span>
            </div>
          </div>

          <div className="space-y-4">
            {report.issues.map((issue, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg ${
                  issue.type === 'error'
                    ? 'bg-red-50'
                    : issue.type === 'warning'
                    ? 'bg-yellow-50'
                    : 'bg-blue-50'
                }`}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <IssueIcon type={issue.type} />
                  </div>
                  <div className="ml-3">
                    <h4 className="text-sm font-medium text-gray-900">
                      {issue.message}
                    </h4>
                    <p className="mt-1 text-sm text-gray-600">
                      {issue.recommendation}
                    </p>
                    <span className={`
                      mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${
                        issue.priority === 'high'
                          ? 'bg-red-100 text-red-800'
                          : issue.priority === 'medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }
                    `}>
                      {issue.priority} priority
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}