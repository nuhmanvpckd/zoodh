import { useState } from 'react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { useGoogleStore } from '../../lib/google/store';
import { BarChart3, Building2, Search } from 'lucide-react';
import type { GoogleAccount } from '../../lib/google/types';

const ACCOUNT_TYPES = {
  business: {
    name: 'Google Business',
    icon: Building2,
    description: 'Manage your business profile and posts',
  },
  analytics: {
    name: 'Google Analytics',
    icon: BarChart3,
    description: 'Track website performance and user behavior',
  },
  'search-console': {
    name: 'Search Console',
    icon: Search,
    description: 'Monitor SEO performance and issues',
  },
};

export function AccountConnection() {
  const [selectedType, setSelectedType] = useState<'business' | 'analytics' | 'search-console' | null>(null);
  const [email, setEmail] = useState('');
  const [locationId, setLocationId] = useState('');
  const addAccount = useGoogleStore((state) => state.addAccount);

  const handleConnect = async () => {
    if (!selectedType || !email) return;

    // In a real implementation, this would handle OAuth flow
    const account: GoogleAccount = {
      id: crypto.randomUUID(),
      type: selectedType,
      name: ACCOUNT_TYPES[selectedType].name,
      email,
      accessToken: 'mock-token',
      refreshToken: 'mock-refresh-token',
      locationId: locationId || undefined,
      status: 'connected',
      lastSync: new Date().toISOString(),
    };

    addAccount(account);
    setSelectedType(null);
    setEmail('');
    setLocationId('');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Connect Google Account</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Account Type
          </label>
          <div className="grid grid-cols-3 gap-4">
            {Object.entries(ACCOUNT_TYPES).map(([type, config]) => {
              const Icon = config.icon;
              return (
                <button
                  key={type}
                  onClick={() => setSelectedType(type as any)}
                  className={`
                    flex flex-col items-center p-4 rounded-lg border-2 transition-all
                    ${selectedType === type 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                    }
                  `}
                >
                  <Icon className="w-8 h-8 text-blue-600 mb-2" />
                  <span className="font-medium text-gray-900">{config.name}</span>
                  <p className="mt-1 text-sm text-gray-500 text-center">
                    {config.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {selectedType && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Google Account Email
              </label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your Google account email"
              />
            </div>

            {selectedType === 'business' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Business Location ID
                </label>
                <Input
                  type="text"
                  value={locationId}
                  onChange={(e) => setLocationId(e.target.value)}
                  placeholder="Enter your Business Location ID"
                />
              </div>
            )}

            <Button
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              onClick={handleConnect}
            >
              Connect {ACCOUNT_TYPES[selectedType].name}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}