import { useState } from 'react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { useSocialStore } from '../../lib/social/store';
import { Calendar, Clock, Image as ImageIcon } from 'lucide-react';
import type { SocialPost } from '../../lib/social/types';

export function PostScheduler() {
  const [content, setContent] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [media, setMedia] = useState<File[]>([]);
  
  const accounts = useSocialStore((state) => state.accounts);
  const addPost = useSocialStore((state) => state.addPost);

  const handleSchedulePost = () => {
    const scheduledDateTime = `${scheduledDate}T${scheduledTime}:00`;

    selectedPlatforms.forEach((platform) => {
      const post: SocialPost = {
        id: crypto.randomUUID(),
        platform: platform as any,
        content,
        scheduledFor: scheduledDateTime,
        status: 'scheduled',
        media: media.map(file => URL.createObjectURL(file)),
      };

      addPost(post);
    });

    // Reset form
    setContent('');
    setScheduledDate('');
    setScheduledTime('');
    setSelectedPlatforms([]);
    setMedia([]);
  };

  const handlePlatformToggle = (platform: string) => {
    setSelectedPlatforms(prev =>
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const handleMediaUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setMedia(prev => [...prev, ...files]);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Schedule Post</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Platforms
          </label>
          <div className="flex space-x-4">
            {accounts.map((account) => (
              <Button
                key={account.id}
                variant={selectedPlatforms.includes(account.platform) ? 'primary' : 'secondary'}
                onClick={() => handlePlatformToggle(account.platform)}
              >
                {account.name}
              </Button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Content
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            rows={4}
            placeholder="What would you like to share?"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Media
          </label>
          <div className="flex items-center space-x-4">
            <Button variant="outline" className="relative">
              <input
                type="file"
                multiple
                accept="image/*,video/*"
                onChange={handleMediaUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <ImageIcon className="w-4 h-4 mr-2" />
              Add Media
            </Button>
            <span className="text-sm text-gray-500">
              {media.length} files selected
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date
            </label>
            <div className="relative">
              <Input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
              />
              <Calendar className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Time
            </label>
            <div className="relative">
              <Input
                type="time"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
              />
              <Clock className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>
        </div>

        <Button
          className="w-full"
          onClick={handleSchedulePost}
          disabled={!content || !scheduledDate || !scheduledTime || selectedPlatforms.length === 0}
        >
          Schedule Post
        </Button>
      </div>
    </div>
  );
}