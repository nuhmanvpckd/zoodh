import { useState } from 'react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { useSocialStore } from '../../lib/social/store';
import { Facebook, Instagram, Share2 } from 'lucide-react';
import type { SocialAccount } from '../../lib/social/types';

const PLATFORM_CONFIG = {
  facebook: {
    name: 'Facebook',
    icon: Facebook,
    color: 'bg-blue-600',
    hoverColor: 'hover:bg-blue-700',
  },
  instagram: {
    name: 'Instagram',
    icon: Instagram,
    color: 'bg-pink-600',
    hoverColor: 'hover:bg-pink-700',
  },
  threads: {
    name: 'Threads',
    icon: Share2,
    color: 'bg-black',
    hoverColor: 'hover:bg-gray-900',
  },
};

export function AccountConnection() {
  const [selectedPlatform, setSelectedPlatform] = useState<'facebook' | 'instagram' | 'threads' | null>(null);
  const [accessToken, setAccessToken] = useState('');
  const [pageId, setPageId] = useState('');
  const addAccount = useSocialStore((state) => state.addAccount);

  const handleConnect = async () => {
    if (!selectedPlatform || !accessToken) return;

    const account: SocialAccount = {
      id: crypto.randomUUID(),
      platform: selectedPlatform,
      name: PLATFORM_CONFIG[selectedPlatform].name,
      accessToken,
      pageId: pageId || undefined,
      status: 'connected',
      lastSync: new Date().toISOString(),
    };

    addAccount(account);
    setSelectedPlatform(null);
    setAccessToken('');
    setPageId('');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Connect Social Media Account</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Platform
          </label>
          <div className="grid grid-cols-3 gap-4">
            {Object.entries(PLATFORM_CONFIG).map(([platform, config]) => {
              const Icon = config.icon;
              return (
                <button
                  key={platform}
                  onClick={() => setSelectedPlatform(platform as any)}
                  className={`
                    flex items-center justify-center p-4 rounded-lg border-2 transition-all
                    ${selectedPlatform === platform 
                      ? `${config.color} text-white` 
                      : 'border-gray-200 hover:border-gray-300'
                    }
                  `}
                >
                  <Icon className="w-6 h-6 mr-2" />
                  <span className="font-medium">{config.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {selectedPlatform && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Access Token
              </label>
              <Input
                type="password"
                value={accessToken}
                onChange={(e) => setAccessToken(e.target.value)}
                placeholder="Enter your access token"
              />
            </div>

            {selectedPlatform === 'facebook' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Page ID (Optional)
                </label>
                <Input
                  type="text"
                  value={pageId}
                  onChange={(e) => setPageId(e.target.value)}
                  placeholder="Enter your Facebook page ID"
                />
              </div>
            )}

            <Button
              className={`w-full ${PLATFORM_CONFIG[selectedPlatform].color} ${PLATFORM_CONFIG[selectedPlatform].hoverColor}`}
              onClick={handleConnect}
            >
              Connect {PLATFORM_CONFIG[selectedPlatform].name}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}