import { useState } from 'react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Bot, Wand2 } from 'lucide-react';

export function AIAssistant() {
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState('');

  const handleGenerateContent = async () => {
    setGenerating(true);
    // Simulate AI content generation
    setTimeout(() => {
      setGeneratedContent(
        'Hey there! 👋 Check out our amazing new products with exclusive discounts just for our WhatsApp community! 🎉 Limited time offer - Don\'t miss out! 🔥'
      );
      setGenerating(false);
    }, 2000);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">AI Message Assistant</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            What kind of message do you want to create?
          </label>
          <Input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="E.g., Create a promotional message for our new product launch"
          />
        </div>

        <Button
          className="w-full"
          onClick={handleGenerateContent}
          disabled={generating || !prompt}
        >
          <Wand2 className="w-4 h-4 mr-2" />
          {generating ? 'Generating...' : 'Generate Message'}
        </Button>

        {generatedContent && (
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Generated Message
            </label>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-start space-x-2">
                <Bot className="w-5 h-5 text-blue-500 mt-1" />
                <p className="text-gray-800">{generatedContent}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}