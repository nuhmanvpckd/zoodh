import { useState } from 'react';
import { Button } from '../ui/Button';
import { useWhatsAppStore } from '../../lib/whatsapp/store';
import { Users, Download } from 'lucide-react';

export function GroupExtractor() {
  const [extracting, setExtracting] = useState(false);
  const addGroup = useWhatsAppStore((state) => state.addGroup);

  const handleExtractGroups = async () => {
    setExtracting(true);
    // Simulated group extraction
    setTimeout(() => {
      const mockGroup = {
        id: crypto.randomUUID(),
        name: 'Marketing Group',
        participantCount: 256,
        participants: ['+1234567890', '+0987654321'],
        extracted: new Date().toISOString(),
      };
      addGroup(mockGroup);
      setExtracting(false);
    }, 2000);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">WhatsApp Group Extractor</h2>
      
      <div className="space-y-4">
        <p className="text-sm text-gray-600">
          Extract participant numbers from your WhatsApp groups for marketing campaigns.
        </p>

        <Button
          className="w-full"
          onClick={handleExtractGroups}
          disabled={extracting}
        >
          <Users className="w-4 h-4 mr-2" />
          {extracting ? 'Extracting...' : 'Extract Group Numbers'}
        </Button>

        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2">Extracted Groups</h3>
          <div className="space-y-2">
            {useWhatsAppStore((state) => state.groups).map((group) => (
              <div
                key={group.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div>
                  <p className="font-medium">{group.name}</p>
                  <p className="text-sm text-gray-500">
                    {group.participantCount} participants
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}