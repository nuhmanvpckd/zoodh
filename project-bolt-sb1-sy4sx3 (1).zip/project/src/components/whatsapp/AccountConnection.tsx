import { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { useWhatsAppStore } from '../../lib/whatsapp/store';
import { WhatsAppClient } from '../../lib/whatsapp/client';
import { MessageSquare, Key } from 'lucide-react';

export function AccountConnection() {
  const [connectionType, setConnectionType] = useState<'web' | 'api'>('web');
  const [apiKey, setApiKey] = useState('');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const addAccount = useWhatsAppStore((state) => state.addAccount);

  useEffect(() => {
    let mounted = true;

    if (connectionType === 'web') {
      const client = WhatsAppClient.getInstance();
      client.connectWebWhatsApp((qr) => {
        if (mounted) {
          setQrCode(qr);
          setError(null);
        }
      }).catch((err) => {
        if (mounted) {
          setError('Failed to connect to WhatsApp service. Please try again.');
          console.error('WhatsApp connection error:', err);
        }
      });
    }

    return () => {
      mounted = false;
    };
  }, [connectionType]);

  const handleConnect = () => {
    if (connectionType === 'api') {
      const account = {
        id: crypto.randomUUID(),
        name,
        phone,
        type: 'api',
        status: 'connected',
        apiKey,
        lastSync: new Date().toISOString(),
      };
      addAccount(account);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Connect WhatsApp Account</h2>
      
      {error && (
        <div className="mb-4 p-4 bg-red-50 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      <div className="space-y-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Connection Type
          </label>
          <div className="flex space-x-4">
            <Button
              variant={connectionType === 'web' ? 'primary' : 'secondary'}
              onClick={() => setConnectionType('web')}
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              WhatsApp Web
            </Button>
            <Button
              variant={connectionType === 'api' ? 'primary' : 'secondary'}
              onClick={() => setConnectionType('api')}
            >
              <Key className="w-4 h-4 mr-2" />
              API Connection
            </Button>
          </div>
        </div>

        {connectionType === 'api' && (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Account Name
              </label>
              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Marketing Account"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number
              </label>
              <Input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1234567890"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                API Key
              </label>
              <Input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Enter your WhatsApp Business API key"
              />
            </div>
          </>
        )}
      </div>

      {connectionType === 'web' && (
        <div className="mb-6">
          <p className="text-sm text-gray-600 mb-4">
            Scan this QR code with WhatsApp on your phone to connect
          </p>
          <div className="flex justify-center p-4 bg-gray-50 rounded-lg">
            {qrCode ? (
              <QRCodeSVG value={qrCode} size={200} />
            ) : (
              <div className="animate-pulse w-[200px] h-[200px] bg-gray-200 rounded" />
            )}
          </div>
          <p className="text-sm text-gray-500 mt-2 text-center">
            Open WhatsApp on your phone, tap Menu or Settings and select WhatsApp Web
          </p>
        </div>
      )}

      {connectionType === 'api' && (
        <Button className="w-full" onClick={handleConnect}>
          Connect Account
        </Button>
      )}
    </div>
  );
}