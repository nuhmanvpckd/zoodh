import { useState } from 'react';
import { Upload, AlertCircle, FileText } from 'lucide-react';
import { Button } from '../ui/Button';
import { installModule } from '../../lib/modules';
import type { Module } from '../../lib/modules';

interface ModuleUploadProps {
  onModuleInstalled: (module: Module) => void;
}

export function ModuleUpload({ onModuleInstalled }: ModuleUploadProps) {
  const [error, setError] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.zip')) {
      setError('Please upload a valid module package (.zip)');
      return;
    }

    setIsUploading(true);
    setError('');

    try {
      const module = await installModule(file);
      onModuleInstalled(module);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to install module');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Upload Module</h3>
          <p className="mt-1 text-sm text-gray-500">
            Upload a custom module package (.zip)
          </p>
        </div>
      </div>

      <div className="mt-4">
        <label
          htmlFor="module-upload"
          className="relative block w-full rounded-lg border-2 border-dashed border-gray-300 p-12 text-center hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <span className="mt-2 block text-sm font-semibold text-gray-900">
            Upload a module
          </span>
          <span className="mt-2 block text-sm text-gray-500">
            Drag and drop or click to select a file
          </span>
          <input
            id="module-upload"
            type="file"
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            accept=".zip"
            onChange={handleFileUpload}
            disabled={isUploading}
          />
        </label>
      </div>

      {error && (
        <div className="mt-4 p-4 rounded-md bg-red-50">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400" />
            <div className="ml-3">
              <p className="text-sm font-medium text-red-800">{error}</p>
            </div>
          </div>
        </div>
      )}

      <div className="mt-6 space-y-4">
        <div>
          <h4 className="text-sm font-medium text-gray-900">Module Requirements</h4>
          <ul className="mt-2 list-disc list-inside text-sm text-gray-600 space-y-1">
            <li>ZIP file format</li>
            <li>Maximum size: 10MB</li>
            <li>Must contain manifest.json</li>
            <li>Supported file types: .js, .css, .json, .svg, .png, .jpg, .jpeg</li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-medium text-gray-900">Manifest Format</h4>
          <div className="mt-2 p-4 bg-gray-50 rounded-md">
            <pre className="text-xs text-gray-600 whitespace-pre-wrap">
{`{
  "name": "module-name",
  "version": "1.0.0",
  "description": "Module description",
  "author": "Author name",
  "dependencies": {
    "optional-dependency": "^1.0.0"
  },
  "minVersion": "1.0.0"
}`}
            </pre>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-blue-600">
          <FileText className="h-4 w-4" />
          <a href="#" className="hover:underline">View documentation</a>
        </div>
      </div>
    </div>
  );
}