import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Login } from './pages/auth/Login';
import { Signup } from './pages/auth/Signup';
import { Dashboard } from './pages/dashboard/Dashboard';
import { ModulesList } from './pages/modules/ModulesList';
import { ModulesBrowse } from './pages/modules/ModulesBrowse';
import { ModulesUpdates } from './pages/modules/ModulesUpdates';
import { Settings } from './pages/settings/Settings';
import { SettingsAccount } from './pages/settings/SettingsAccount';
import { SettingsIntegrations } from './pages/settings/SettingsIntegrations';
import { SettingsBilling } from './pages/settings/SettingsBilling';
import { WhatsAppDashboard } from './pages/whatsapp/WhatsAppDashboard';
import { SocialDashboard } from './pages/social/SocialDashboard';
import { GoogleDashboard } from './pages/google/GoogleDashboard';
import { useAuthStore } from './store/auth';
import { useEffect } from 'react';
import { initializeSchema } from './lib/db';

interface PrivateRouteProps {
  children: React.ReactNode;
}

function PrivateRoute({ children }: PrivateRouteProps) {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
}

function App() {
  useEffect(() => {
    initializeSchema().catch(console.error);
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/whatsapp"
          element={
            <PrivateRoute>
              <WhatsAppDashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/social"
          element={
            <PrivateRoute>
              <SocialDashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/google"
          element={
            <PrivateRoute>
              <GoogleDashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/modules"
          element={
            <PrivateRoute>
              <ModulesList />
            </PrivateRoute>
          }
        />
        <Route
          path="/modules/browse"
          element={
            <PrivateRoute>
              <ModulesBrowse />
            </PrivateRoute>
          }
        />
        <Route
          path="/modules/updates"
          element={
            <PrivateRoute>
              <ModulesUpdates />
            </PrivateRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <PrivateRoute>
              <Settings />
            </PrivateRoute>
          }
        />
        <Route
          path="/settings/account"
          element={
            <PrivateRoute>
              <SettingsAccount />
            </PrivateRoute>
          }
        />
        <Route
          path="/settings/integrations"
          element={
            <PrivateRoute>
              <SettingsIntegrations />
            </PrivateRoute>
          }
        />
        <Route
          path="/settings/billing"
          element={
            <PrivateRoute>
              <SettingsBilling />
            </PrivateRoute>
          }
        />
        <Route path="/" element={<Navigate to="/dashboard" />} />
      </Routes>
    </Router>
  );
}

export default App;