import { Layout } from '../../components/Layout';
import { AccountConnection } from '../../components/google/AccountConnection';
import { SEOAnalyzer } from '../../components/google/SEOAnalyzer';
import { useState } from 'react';
import { Search, Building2, BarChart3, Settings } from 'lucide-react';

export function GoogleDashboard() {
  const [activeTab, setActiveTab] = useState('seo');

  const tabs = [
    { id: 'seo', name: 'SEO Analysis', icon: Search },
    { id: 'business', name: 'Business Profile', icon: Building2 },
    { id: 'analytics', name: 'Analytics', icon: BarChart3 },
    { id: 'settings', name: 'Account Settings', icon: Settings },
  ];

  return (
    <Layout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Google Marketing</h1>
          
          <div className="mt-4 border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm
                      ${
                        activeTab === tab.id
                          ? 'border-blue-500 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      }
                    `}
                  >
                    <Icon className={`
                      -ml-0.5 mr-2 h-5 w-5
                      ${activeTab === tab.id ? 'text-blue-500' : 'text-gray-400 group-hover:text-gray-500'}
                    `} />
                    {tab.name}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="mt-6">
            {activeTab === 'seo' && <SEOAnalyzer />}
            {activeTab === 'settings' && <AccountConnection />}
          </div>
        </div>
      </div>
    </Layout>
  );
}