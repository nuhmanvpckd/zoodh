import { Layout } from '../../components/Layout';
import { RefreshCw, Package, ArrowUpCircle } from 'lucide-react';
import { Button } from '../../components/ui/Button';

const updates = [
  {
    id: 1,
    name: 'Analytics Dashboard',
    currentVersion: '1.2.0',
    newVersion: '1.3.0',
    changes: [
      'Improved performance metrics',
      'New social media platform integrations',
      'Bug fixes and UI improvements',
    ],
  },
  {
    id: 2,
    name: 'Social Media Scheduler',
    currentVersion: '2.0.1',
    newVersion: '2.1.0',
    changes: [
      'Added bulk scheduling feature',
      'Enhanced calendar view',
      'Performance optimizations',
    ],
  },
];

export function ModulesUpdates() {
  return (
    <Layout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">
                Module Updates
              </h1>
              <p className="mt-2 text-sm text-gray-600">
                Keep your modules up to date with the latest features and improvements
              </p>
            </div>
            <Button variant="secondary" size="sm">
              <RefreshCw className="mr-2 h-4 w-4" />
              Check for Updates
            </Button>
          </div>
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="mt-8 space-y-6">
            {updates.map((update) => (
              <div
                key={update.id}
                className="bg-white overflow-hidden rounded-lg shadow"
              >
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Package className="h-8 w-8 text-blue-500" />
                      <div className="ml-4">
                        <h3 className="text-lg font-medium text-gray-900">
                          {update.name}
                        </h3>
                        <p className="mt-1 text-sm text-gray-500">
                          Update available: {update.currentVersion} →{' '}
                          <span className="font-medium text-blue-600">
                            {update.newVersion}
                          </span>
                        </p>
                      </div>
                    </div>
                    <Button variant="primary" size="sm">
                      <ArrowUpCircle className="mr-2 h-4 w-4" />
                      Update
                    </Button>
                  </div>
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-gray-900">
                      What's new:
                    </h4>
                    <ul className="mt-2 list-disc list-inside space-y-1">
                      {update.changes.map((change, index) => (
                        <li key={index} className="text-sm text-gray-600">
                          {change}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}