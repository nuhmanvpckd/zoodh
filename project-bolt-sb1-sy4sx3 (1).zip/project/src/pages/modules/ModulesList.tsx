import { Layout } from '../../components/Layout';
import { Package, RefreshCw, Trash2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { ModuleUpload } from '../../components/modules/ModuleUpload';
import { useState, useEffect } from 'react';
import { getInstalledModules, toggleModuleStatus, uninstallModule } from '../../lib/modules';
import type { Module } from '../../lib/modules';

export function ModulesList() {
  const [modules, setModules] = useState<Module[]>([]);
  const [showUpload, setShowUpload] = useState(false);

  useEffect(() => {
    setModules(getInstalledModules());
  }, []);

  const handleModuleInstalled = (module: Module) => {
    setModules((prev) => [...prev, module]);
    setShowUpload(false);
  };

  const handleToggleStatus = (moduleId: string) => {
    try {
      const updatedModule = toggleModuleStatus(moduleId);
      setModules((prev) =>
        prev.map((m) => (m.id === moduleId ? updatedModule : m))
      );
    } catch (error) {
      console.error('Failed to toggle module status:', error);
    }
  };

  const handleUninstall = (moduleId: string) => {
    try {
      uninstallModule(moduleId);
      setModules((prev) => prev.filter((m) => m.id !== moduleId));
    } catch (error) {
      console.error('Failed to uninstall module:', error);
    }
  };

  return (
    <Layout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-semibold text-gray-900">
              Installed Modules
            </h1>
            <Button
              variant="primary"
              size="sm"
              onClick={() => setShowUpload(!showUpload)}
            >
              {showUpload ? 'Cancel Upload' : 'Upload Module'}
            </Button>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          {showUpload && (
            <div className="my-6">
              <ModuleUpload onModuleInstalled={handleModuleInstalled} />
            </div>
          )}

          <div className="mt-8 flex flex-col">
            <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div className="inline-block min-w-full py-2 align-middle md:px-6 lg:px-8">
                <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                  <table className="min-w-full divide-y divide-gray-300">
                    <thead className="bg-gray-50">
                      <tr>
                        <th
                          scope="col"
                          className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6"
                        >
                          Module
                        </th>
                        <th
                          scope="col"
                          className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                        >
                          Version
                        </th>
                        <th
                          scope="col"
                          className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                        >
                          Author
                        </th>
                        <th
                          scope="col"
                          className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                        >
                          Status
                        </th>
                        <th
                          scope="col"
                          className="relative py-3.5 pl-3 pr-4 sm:pr-6"
                        >
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 bg-white">
                      {modules.map((module) => (
                        <tr key={module.id}>
                          <td className="whitespace-nowrap py-4 pl-4 pr-3 sm:pl-6">
                            <div className="flex items-center">
                              <Package className="h-6 w-6 text-gray-400" />
                              <div className="ml-4">
                                <div className="font-medium text-gray-900">
                                  {module.name}
                                </div>
                                <div className="text-gray-500">
                                  {module.description}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {module.version}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {module.author}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm">
                            <button
                              onClick={() => handleToggleStatus(module.id)}
                              className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                                module.status === 'active'
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {module.status}
                            </button>
                          </td>
                          <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => handleToggleStatus(module.id)}
                              >
                                <RefreshCw className="h-4 w-4" />
                                <span className="sr-only">Toggle Status</span>
                              </Button>
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => handleUninstall(module.id)}
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                                <span className="sr-only">Uninstall</span>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}