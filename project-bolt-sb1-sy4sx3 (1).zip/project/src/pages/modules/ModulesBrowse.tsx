import { Layout } from '../../components/Layout';
import { Package, Download } from 'lucide-react';
import { Button } from '../../components/ui/Button';

const availableModules = [
  {
    id: 1,
    name: 'Social Media Analytics Pro',
    description: 'Advanced analytics and insights for social media performance',
    version: '2.0.0',
    price: 'Free',
  },
  {
    id: 2,
    name: 'Auto Content Generator',
    description: 'AI-powered content generation for multiple platforms',
    version: '1.5.0',
    price: '$29/month',
  },
  {
    id: 3,
    name: 'Competitor Analysis',
    description: 'Track and analyze competitor social media activities',
    version: '1.0.0',
    price: '$49/month',
  },
];

export function ModulesBrowse() {
  return (
    <Layout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Browse Modules</h1>
          <p className="mt-2 text-sm text-gray-600">
            Discover and install new modules to enhance your social media management
          </p>
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {availableModules.map((module) => (
              <div
                key={module.id}
                className="bg-white overflow-hidden rounded-lg shadow"
              >
                <div className="p-6">
                  <div className="flex items-center">
                    <Package className="h-8 w-8 text-blue-500" />
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">
                        {module.name}
                      </h3>
                      <p className="mt-1 text-sm text-gray-500">
                        Version {module.version}
                      </p>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-gray-600">
                    {module.description}
                  </p>
                  <div className="mt-6 flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">
                      {module.price}
                    </span>
                    <Button variant="primary" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Install
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}