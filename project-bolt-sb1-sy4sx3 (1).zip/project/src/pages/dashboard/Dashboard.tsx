import { Layout } from '../../components/Layout';
import { 
  BarChart3, Users, MessageSquare, Calendar,
  TrendingUp, ArrowUpRight, ArrowDownRight,
  Activity, Globe, Share2, Search
} from 'lucide-react';
import { useState } from 'react';

const stats = [
  { 
    name: 'Total Engagement',
    value: '156K',
    change: '+12.5%',
    trend: 'up',
    icon: Activity,
    color: 'bg-blue-500'
  },
  { 
    name: 'Social Reach',
    value: '2.4M',
    change: '+23.1%',
    trend: 'up',
    icon: Share2,
    color: 'bg-indigo-500'
  },
  { 
    name: 'Website Traffic',
    value: '892K',
    change: '-4.3%',
    trend: 'down',
    icon: Globe,
    color: 'bg-purple-500'
  },
  { 
    name: 'Search Rankings',
    value: '45',
    change: '+8.7%',
    trend: 'up',
    icon: Search,
    color: 'bg-pink-500'
  },
];

const platforms = [
  { name: 'Facebook', value: 45, color: 'bg-blue-500' },
  { name: 'Instagram', value: 35, color: 'bg-pink-500' },
  { name: 'Twitter', value: 15, color: 'bg-sky-500' },
  { name: 'LinkedIn', value: 5, color: 'bg-blue-700' },
];

export function Dashboard() {
  const [timeRange, setTimeRange] = useState('7d');

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50">
        <div className="py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-semibold text-gray-900">Analytics Overview</h1>
                <p className="mt-1 text-sm text-gray-500">Track your marketing performance across all channels</p>
              </div>
              <div className="flex items-center space-x-3">
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value)}
                  className="rounded-lg border-gray-300 py-2 pl-3 pr-10 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="24h">Last 24 hours</option>
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                  <option value="90d">Last 90 days</option>
                </select>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((stat) => {
                const Icon = stat.icon;
                return (
                  <div
                    key={stat.name}
                    className="relative overflow-hidden rounded-lg bg-white px-4 py-5 shadow transition-all hover:shadow-lg sm:p-6"
                  >
                    <div className="absolute bottom-0 right-0 -mb-6 -mr-6 opacity-10">
                      <Icon className="h-24 w-24" />
                    </div>
                    <dt>
                      <div className={`absolute rounded-md p-3 ${stat.color}`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="ml-16 truncate text-sm font-medium text-gray-500">{stat.name}</p>
                    </dt>
                    <dd className="ml-16 flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
                      <p className={`ml-2 flex items-baseline text-sm font-semibold ${
                        stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {stat.trend === 'up' ? (
                          <ArrowUpRight className="h-4 w-4" />
                        ) : (
                          <ArrowDownRight className="h-4 w-4" />
                        )}
                        <span className="ml-1">{stat.change}</span>
                      </p>
                    </dd>
                  </div>
                );
              })}
            </div>

            {/* Charts Section */}
            <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-2">
              {/* Engagement Chart */}
              <div className="rounded-lg bg-white p-6 shadow">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-gray-900">Engagement Trends</h2>
                  <div className="flex items-center space-x-2">
                    <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                      <TrendingUp className="-ml-0.5 mr-1 h-3 w-3" />
                      12.5%
                    </span>
                  </div>
                </div>
                <div className="mt-6 h-72 w-full bg-gray-50 flex items-center justify-center">
                  <p className="text-gray-500">Engagement Chart Placeholder</p>
                </div>
              </div>

              {/* Platform Distribution */}
              <div className="rounded-lg bg-white p-6 shadow">
                <h2 className="text-lg font-medium text-gray-900">Platform Distribution</h2>
                <div className="mt-6 space-y-4">
                  {platforms.map((platform) => (
                    <div key={platform.name}>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">{platform.name}</span>
                        <span className="font-medium text-gray-900">{platform.value}%</span>
                      </div>
                      <div className="mt-2 overflow-hidden rounded-full bg-gray-100">
                        <div
                          className={`h-2 ${platform.color}`}
                          style={{ width: `${platform.value}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="mt-8">
              <div className="rounded-lg bg-white shadow">
                <div className="p-6">
                  <h2 className="text-lg font-medium text-gray-900">Recent Activity</h2>
                  <div className="mt-6 flow-root">
                    <ul className="-my-5 divide-y divide-gray-200">
                      {[1, 2, 3].map((item) => (
                        <li key={item} className="py-5">
                          <div className="relative focus-within:ring-2 focus-within:ring-blue-500">
                            <h3 className="text-sm font-semibold text-gray-800">
                              <a href="#" className="hover:underline focus:outline-none">
                                New post published on Instagram
                                <span className="absolute inset-0" aria-hidden="true" />
                              </a>
                            </h3>
                            <p className="mt-1 text-sm text-gray-600 line-clamp-2">
                              Your recent post "Summer Collection 2024" has received 1.2K likes and 234 comments.
                            </p>
                            <p className="mt-2 text-sm text-gray-500">2 hours ago</p>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-6">
                    <a
                      href="#"
                      className="flex items-center justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-blue-600 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
                    >
                      View all
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}