import { Layout } from '../../components/Layout';
import { Button } from '../../components/ui/Button';
import { CreditCard, Package } from 'lucide-react';

const plans = [
  {
    name: 'Basic',
    price: '$29',
    features: [
      '5 social media accounts',
      'Basic analytics',
      'Content scheduling',
      'Email support',
    ],
    current: false,
  },
  {
    name: 'Professional',
    price: '$79',
    features: [
      '15 social media accounts',
      'Advanced analytics',
      'Content scheduling',
      'Priority support',
      'Team collaboration',
    ],
    current: true,
  },
  {
    name: 'Enterprise',
    price: '$199',
    features: [
      'Unlimited social accounts',
      'Custom analytics',
      'Advanced scheduling',
      '24/7 priority support',
      'Team collaboration',
      'Custom integrations',
    ],
    current: false,
  },
];

export function SettingsBilling() {
  return (
    <Layout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Billing & Plans</h1>
          <p className="mt-2 text-sm text-gray-600">
            Manage your subscription and billing information
          </p>
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="mt-8">
            {/* Current Plan */}
            <div className="bg-white shadow sm:rounded-lg mb-8">
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">
                  Current Plan
                </h3>
                <div className="mt-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">You are currently on the</p>
                    <p className="text-2xl font-semibold text-gray-900">Professional Plan</p>
                    <p className="text-sm text-gray-500">Billing monthly • Next payment on April 1, 2024</p>
                  </div>
                  <Button variant="outline">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Update Payment Method
                  </Button>
                </div>
              </div>
            </div>

            {/* Available Plans */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Available Plans</h3>
              <div className="grid gap-6 lg:grid-cols-3">
                {plans.map((plan) => (
                  <div
                    key={plan.name}
                    className={`rounded-lg shadow-sm divide-y divide-gray-200 ${
                      plan.current ? 'border-2 border-blue-500' : ''
                    }`}
                  >
                    <div className="p-6">
                      <h2 className="text-xl font-semibold text-gray-900">{plan.name}</h2>
                      <p className="mt-4">
                        <span className="text-4xl font-extrabold text-gray-900">{plan.price}</span>
                        <span className="text-base font-medium text-gray-500">/month</span>
                      </p>
                      <Button
                        variant={plan.current ? 'secondary' : 'primary'}
                        className="mt-8 w-full"
                      >
                        {plan.current ? 'Current Plan' : 'Upgrade'}
                      </Button>
                    </div>
                    <div className="px-6 pt-6 pb-8">
                      <h3 className="text-sm font-medium text-gray-900 tracking-wide uppercase">
                        What's included
                      </h3>
                      <ul className="mt-6 space-y-4">
                        {plan.features.map((feature) => (
                          <li key={feature} className="flex space-x-3">
                            <Package className="flex-shrink-0 h-5 w-5 text-green-500" />
                            <span className="text-sm text-gray-500">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}