import { Layout } from '../../components/Layout';
import { Button } from '../../components/ui/Button';
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Slack, Toggle } from 'lucide-react';
import { useState } from 'react';

interface Integration {
  id: string;
  name: string;
  icon: React.ElementType;
  connected: boolean;
  status: 'connected' | 'disconnected';
  lastSync?: string;
  account?: string;
}

const socialIntegrations: Integration[] = [
  {
    id: 'facebook',
    name: 'Facebook',
    icon: Facebook,
    connected: true,
    status: 'connected',
    lastSync: '2 hours ago',
    account: 'John Doe',
  },
  {
    id: 'twitter',
    name: 'Twitter',
    icon: Twitter,
    connected: true,
    status: 'connected',
    lastSync: '1 hour ago',
    account: '@johndoe',
  },
  {
    id: 'instagram',
    name: 'Instagram',
    icon: Instagram,
    connected: false,
    status: 'disconnected',
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    icon: Linkedin,
    connected: true,
    status: 'connected',
    lastSync: '3 hours ago',
    account: 'John Doe',
  },
  {
    id: 'youtube',
    name: 'YouTube',
    icon: Youtube,
    connected: false,
    status: 'disconnected',
  },
];

const thirdPartyIntegrations: Integration[] = [
  {
    id: 'slack',
    name: 'Slack',
    icon: Slack,
    connected: true,
    status: 'connected',
    lastSync: '30 minutes ago',
    account: 'Marketing Team',
  },
];

export function SettingsIntegrations() {
  const [integrations, setIntegrations] = useState({
    social: socialIntegrations,
    thirdParty: thirdPartyIntegrations,
  });

  const handleToggleIntegration = (type: 'social' | 'thirdParty', id: string) => {
    setIntegrations((prev) => ({
      ...prev,
      [type]: prev[type].map((integration) =>
        integration.id === id
          ? {
              ...integration,
              connected: !integration.connected,
              status: integration.connected ? 'disconnected' : 'connected',
            }
          : integration
      ),
    }));
  };

  const IntegrationCard = ({ integration, type }: { integration: Integration; type: 'social' | 'thirdParty' }) => {
    const Icon = integration.icon;
    
    return (
      <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow">
        <div className="flex items-center space-x-4">
          <div className="flex-shrink-0">
            <Icon className="w-8 h-8 text-gray-500" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900">{integration.name}</h3>
            <div className="mt-1">
              {integration.connected ? (
                <div className="text-sm text-gray-500">
                  Connected as {integration.account}
                  {integration.lastSync && (
                    <span className="ml-2">• Last synced {integration.lastSync}</span>
                  )}
                </div>
              ) : (
                <span className="text-sm text-gray-500">Not connected</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={() => handleToggleIntegration(type, integration.id)}
            className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
              integration.connected ? 'bg-blue-600' : 'bg-gray-200'
            }`}
          >
            <span className="sr-only">Toggle integration</span>
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                integration.connected ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => handleToggleIntegration(type, integration.id)}
          >
            {integration.connected ? 'Disconnect' : 'Connect'}
          </Button>
        </div>
      </div>
    );
  };

  return (
    <Layout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Integrations</h1>
          <p className="mt-2 text-sm text-gray-600">
            Connect and manage your social media accounts and third-party integrations
          </p>
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="mt-8 space-y-8">
            {/* Social Media Integrations */}
            <div>
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                Social Media Platforms
              </h2>
              <div className="space-y-4">
                {integrations.social.map((integration) => (
                  <IntegrationCard
                    key={integration.id}
                    integration={integration}
                    type="social"
                  />
                ))}
              </div>
            </div>

            {/* Third-party Integrations */}
            <div>
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                Third-party Integrations
              </h2>
              <div className="space-y-4">
                {integrations.thirdParty.map((integration) => (
                  <IntegrationCard
                    key={integration.id}
                    integration={integration}
                    type="thirdParty"
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}