import { Layout } from '../../components/Layout';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuthStore } from '../../store/auth';
import { useState } from 'react';
import { Camera } from 'lucide-react';

export function SettingsAccount() {
  const user = useAuthStore((state) => state.user);
  const [isEditing, setIsEditing] = useState(false);

  return (
    <Layout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Account Settings</h1>
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="mt-8">
            <div className="space-y-6 bg-white shadow sm:rounded-lg">
              {/* Profile Photo Section */}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">
                  Profile Photo
                </h3>
                <div className="mt-4 flex items-center space-x-4">
                  <div className="relative">
                    <img
                      src={user?.avatar || 'https://ui-avatars.com/api/?name=User'}
                      alt="Profile"
                      className="h-16 w-16 rounded-full object-cover"
                    />
                    <button className="absolute bottom-0 right-0 rounded-full bg-blue-600 p-1.5 text-white hover:bg-blue-700">
                      <Camera className="h-4 w-4" />
                    </button>
                  </div>
                  <Button variant="secondary" size="sm">
                    Change Photo
                  </Button>
                </div>
              </div>

              {/* Personal Information Section */}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">
                  Personal Information
                </h3>
                <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                  <div className="sm:col-span-3">
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Full Name
                    </label>
                    <div className="mt-1">
                      <Input
                        type="text"
                        name="name"
                        id="name"
                        defaultValue={user?.name}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-3">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email Address
                    </label>
                    <div className="mt-1">
                      <Input
                        type="email"
                        name="email"
                        id="email"
                        defaultValue={user?.email}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-3">
                    <label htmlFor="role" className="block text-sm font-medium text-gray-700">
                      Role
                    </label>
                    <div className="mt-1">
                      <Input
                        type="text"
                        name="role"
                        id="role"
                        defaultValue={user?.role}
                        disabled
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Password Section */}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">
                  Change Password
                </h3>
                <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                  <div className="sm:col-span-3">
                    <label htmlFor="current-password" className="block text-sm font-medium text-gray-700">
                      Current Password
                    </label>
                    <div className="mt-1">
                      <Input
                        type="password"
                        name="current-password"
                        id="current-password"
                        disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-3">
                    <label htmlFor="new-password" className="block text-sm font-medium text-gray-700">
                      New Password
                    </label>
                    <div className="mt-1">
                      <Input
                        type="password"
                        name="new-password"
                        id="new-password"
                        disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-3">
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700">
                      Confirm New Password
                    </label>
                    <div className="mt-1">
                      <Input
                        type="password"
                        name="confirm-password"
                        id="confirm-password"
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="bg-gray-50 px-4 py-3 text-right sm:px-6 space-x-3">
                {!isEditing ? (
                  <Button onClick={() => setIsEditing(true)}>
                    Edit Profile
                  </Button>
                ) : (
                  <>
                    <Button variant="secondary" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                    <Button onClick={() => setIsEditing(false)}>
                      Save Changes
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}