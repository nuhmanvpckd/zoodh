export interface GoogleAccount {
  id: string;
  type: 'business' | 'analytics' | 'search-console';
  name: string;
  email: string;
  accessToken: string;
  refreshToken: string;
  locationId?: string;
  status: 'connected' | 'disconnected';
  lastSync?: string;
}

export interface BusinessPost {
  id: string;
  content: string;
  media?: string[];
  scheduledFor?: string;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  locationId: string;
  insights?: BusinessPostInsights;
}

export interface BusinessPostInsights {
  views: number;
  clicks: number;
  calls: number;
  directions: number;
}

export interface SEOReport {
  id: string;
  url: string;
  score: number;
  issues: SEOIssue[];
  lastUpdated: string;
}

export interface SEOIssue {
  type: 'error' | 'warning' | 'info';
  message: string;
  priority: 'high' | 'medium' | 'low';
  recommendation: string;
}

export interface AnalyticsData {
  pageViews: number;
  uniqueVisitors: number;
  bounceRate: number;
  avgSessionDuration: number;
  topPages: Array<{
    url: string;
    views: number;
    avgTimeOnPage: number;
  }>;
}