import { create } from 'zustand';
import type { GoogleAccount, BusinessPost, SEOReport, AnalyticsData } from './types';

interface GoogleStore {
  accounts: GoogleAccount[];
  posts: BusinessPost[];
  seoReports: SEOReport[];
  analyticsData: AnalyticsData | null;
  addAccount: (account: GoogleAccount) => void;
  removeAccount: (id: string) => void;
  updateAccount: (id: string, data: Partial<GoogleAccount>) => void;
  addPost: (post: BusinessPost) => void;
  updatePost: (id: string, data: Partial<BusinessPost>) => void;
  addSEOReport: (report: SEOReport) => void;
  updateAnalytics: (data: AnalyticsData) => void;
}

export const useGoogleStore = create<GoogleStore>((set) => ({
  accounts: [],
  posts: [],
  seoReports: [],
  analyticsData: null,
  
  addAccount: (account) =>
    set((state) => ({ accounts: [...state.accounts, account] })),
    
  removeAccount: (id) =>
    set((state) => ({
      accounts: state.accounts.filter((account) => account.id !== id),
    })),
    
  updateAccount: (id, data) =>
    set((state) => ({
      accounts: state.accounts.map((account) =>
        account.id === id ? { ...account, ...data } : account
      ),
    })),
    
  addPost: (post) =>
    set((state) => ({ posts: [...state.posts, post] })),
    
  updatePost: (id, data) =>
    set((state) => ({
      posts: state.posts.map((post) =>
        post.id === id ? { ...post, ...data } : post
      ),
    })),
    
  addSEOReport: (report) =>
    set((state) => ({ seoReports: [...state.seoReports, report] })),
    
  updateAnalytics: (data) =>
    set({ analyticsData: data }),
}));