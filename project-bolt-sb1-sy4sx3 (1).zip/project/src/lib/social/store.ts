import { create } from 'zustand';
import type { SocialAccount, SocialPost } from './types';

interface SocialStore {
  accounts: SocialAccount[];
  posts: SocialPost[];
  addAccount: (account: SocialAccount) => void;
  removeAccount: (id: string) => void;
  updateAccount: (id: string, data: Partial<SocialAccount>) => void;
  addPost: (post: SocialPost) => void;
  updatePost: (id: string, data: Partial<SocialPost>) => void;
  deletePost: (id: string) => void;
}

export const useSocialStore = create<SocialStore>((set) => ({
  accounts: [],
  posts: [],
  
  addAccount: (account) =>
    set((state) => ({ accounts: [...state.accounts, account] })),
    
  removeAccount: (id) =>
    set((state) => ({
      accounts: state.accounts.filter((account) => account.id !== id),
    })),
    
  updateAccount: (id, data) =>
    set((state) => ({
      accounts: state.accounts.map((account) =>
        account.id === id ? { ...account, ...data } : account
      ),
    })),
    
  addPost: (post) =>
    set((state) => ({ posts: [...state.posts, post] })),
    
  updatePost: (id, data) =>
    set((state) => ({
      posts: state.posts.map((post) =>
        post.id === id ? { ...post, ...data } : post
      ),
    })),
    
  deletePost: (id) =>
    set((state) => ({
      posts: state.posts.filter((post) => post.id !== id),
    })),
}));