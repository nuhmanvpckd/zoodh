export interface SocialAccount {
  id: string;
  platform: 'facebook' | 'instagram' | 'threads';
  name: string;
  accessToken: string;
  pageId?: string;
  status: 'connected' | 'disconnected';
  lastSync?: string;
}

export interface SocialPost {
  id: string;
  platform: 'facebook' | 'instagram' | 'threads';
  content: string;
  media?: string[];
  scheduledFor?: string;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  insights?: PostInsights;
}

export interface PostInsights {
  likes: number;
  comments: number;
  shares: number;
  reach: number;
  engagement: number;
}

export interface ScheduleSettings {
  timezone: string;
  bestTimes: string[];
  frequency: 'daily' | 'weekly' | 'custom';
  customDays?: string[];
}