import { useWhatsAppStore } from './store';
import type { WhatsAppAccount } from './types';

export class WhatsAppClient {
  private static instance: WhatsAppClient;
  private socket: WebSocket | null = null;
  private qrCallback: ((qr: string) => void) | null = null;
  private connectionPromise: Promise<void> | null = null;

  private constructor() {
    this.initializeSocket();
  }

  static getInstance(): WhatsAppClient {
    if (!WhatsAppClient.instance) {
      WhatsAppClient.instance = new WhatsAppClient();
    }
    return WhatsAppClient.instance;
  }

  private initializeSocket() {
    this.connectionPromise = new Promise((resolve, reject) => {
      try {
        this.socket = new WebSocket('wss://your-whatsapp-service.com');

        this.socket.onopen = () => {
          resolve();
        };

        this.socket.onerror = (error) => {
          reject(error);
        };

        this.socket.onmessage = (event) => {
          const data = JSON.parse(event.data);
          
          if (data.type === 'qr') {
            this.qrCallback?.(data.qr);
          } else if (data.type === 'ready') {
            const { addAccount } = useWhatsAppStore.getState();
            const account: WhatsAppAccount = {
              id: crypto.randomUUID(),
              name: 'WhatsApp Web',
              phone: data.phone,
              type: 'web',
              status: 'connected',
              lastSync: new Date().toISOString(),
            };
            addAccount(account);
          }
        };
      } catch (error) {
        reject(error);
      }
    });
  }

  private async ensureConnected(): Promise<void> {
    if (!this.socket || this.socket.readyState !== WebSocket.OPEN) {
      this.initializeSocket();
    }
    await this.connectionPromise;
  }

  async connectWebWhatsApp(onQRCode: (qr: string) => void): Promise<void> {
    try {
      await this.ensureConnected();
      this.qrCallback = onQRCode;
      
      // For demo purposes, simulate a QR code
      setTimeout(() => {
        onQRCode('https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=demo-whatsapp-connection');
      }, 1000);
      
      // In production, you would send the init message
      // this.socket?.send(JSON.stringify({ type: 'init' }));
    } catch (error) {
      console.error('Failed to connect to WhatsApp:', error);
      throw new Error('Failed to connect to WhatsApp service');
    }
  }

  async sendMessage(to: string, message: string): Promise<void> {
    await this.ensureConnected();
    
    this.socket?.send(JSON.stringify({
      type: 'send_message',
      data: { to, message }
    }));
  }

  async sendBulkMessages(numbers: string[], message: string): Promise<void> {
    await this.ensureConnected();
    
    for (const number of numbers) {
      await this.sendMessage(number, message);
      // Add delay to prevent rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  async extractGroupParticipants(groupId: string): Promise<string[]> {
    await this.ensureConnected();
    
    return new Promise((resolve) => {
      this.socket?.send(JSON.stringify({
        type: 'extract_group',
        data: { groupId }
      }));

      const handler = (event: MessageEvent) => {
        const data = JSON.parse(event.data);
        if (data.type === 'group_participants') {
          this.socket?.removeEventListener('message', handler);
          resolve(data.participants);
        }
      };

      this.socket?.addEventListener('message', handler);
    });
  }

  disconnect(): void {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.close();
    }
    this.socket = null;
    this.qrCallback = null;
    this.connectionPromise = null;
  }
}