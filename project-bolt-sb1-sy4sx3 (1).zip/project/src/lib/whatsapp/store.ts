import { create } from 'zustand';
import type { WhatsAppAccount, WhatsAppMessage, WhatsAppGroup, WhatsAppTemplate } from './types';

interface WhatsAppStore {
  accounts: WhatsAppAccount[];
  messages: WhatsAppMessage[];
  groups: WhatsAppGroup[];
  templates: WhatsAppTemplate[];
  addAccount: (account: WhatsAppAccount) => void;
  removeAccount: (id: string) => void;
  updateAccount: (id: string, data: Partial<WhatsAppAccount>) => void;
  addMessage: (message: WhatsAppMessage) => void;
  updateMessage: (id: string, data: Partial<WhatsAppMessage>) => void;
  addGroup: (group: WhatsAppGroup) => void;
  addTemplate: (template: WhatsAppTemplate) => void;
}

export const useWhatsAppStore = create<WhatsAppStore>((set) => ({
  accounts: [],
  messages: [],
  groups: [],
  templates: [],
  
  addAccount: (account) =>
    set((state) => ({ accounts: [...state.accounts, account] })),
    
  removeAccount: (id) =>
    set((state) => ({
      accounts: state.accounts.filter((account) => account.id !== id),
    })),
    
  updateAccount: (id, data) =>
    set((state) => ({
      accounts: state.accounts.map((account) =>
        account.id === id ? { ...account, ...data } : account
      ),
    })),
    
  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),
    
  updateMessage: (id, data) =>
    set((state) => ({
      messages: state.messages.map((message) =>
        message.id === id ? { ...message, ...data } : message
      ),
    })),
    
  addGroup: (group) =>
    set((state) => ({ groups: [...state.groups, group] })),
    
  addTemplate: (template) =>
    set((state) => ({ templates: [...state.templates, template] })),
}));