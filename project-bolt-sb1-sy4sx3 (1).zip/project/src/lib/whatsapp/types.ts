export interface WhatsAppAccount {
  id: string;
  name: string;
  phone: string;
  type: 'web' | 'api';
  status: 'connected' | 'disconnected';
  apiKey?: string;
  lastSync?: string;
}

export interface WhatsAppMessage {
  id: string;
  content: string;
  type: 'text' | 'template' | 'media';
  scheduledFor?: string;
  status: 'scheduled' | 'sent' | 'failed';
  recipients: string[];
  groupIds?: string[];
}

export interface WhatsAppGroup {
  id: string;
  name: string;
  participantCount: number;
  participants: string[];
  extracted: string;
}

export interface WhatsAppTemplate {
  id: string;
  name: string;
  content: string;
  variables: string[];
}