import type { User } from '../types/auth';
import { getUserByEmail } from './db';

export async function loginUser(email: string, password: string): Promise<Omit<User, 'password'>> {
  const user = await getUserByEmail(email);
  
  if (!user || user.password !== password) {
    throw new Error('Invalid email or password');
  }

  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
}

export async function createUser(userData: Omit<User, 'id'>) {
  const existingUser = await getUserByEmail(userData.email);
  
  if (existingUser) {
    throw new Error('User already exists');
  }

  const newUser: User = {
    ...userData,
    id: crypto.randomUUID(),
  };

  const users = JSON.parse(localStorage.getItem('social_media_users') || '[]');
  users.push(newUser);
  localStorage.setItem('social_media_users', JSON.stringify(users));
  
  const { password: _, ...userWithoutPassword } = newUser;
  return userWithoutPassword;
}