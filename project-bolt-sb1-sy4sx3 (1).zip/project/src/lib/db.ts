import type { User } from '../types/auth';

const USERS_KEY = 'social_media_users';

const DEFAULT_ADMIN: User = {
  id: 'admin-1',
  email: 'admin@example.com',
  password: 'admin123',
  name: 'Admin User',
  role: 'admin',
  avatar: 'https://ui-avatars.com/api/?name=Admin+User'
};

export async function initDb() {
  if (!localStorage.getItem(USERS_KEY)) {
    localStorage.setItem(USERS_KEY, JSON.stringify([DEFAULT_ADMIN]));
  }
}

export async function getUserByEmail(email: string): Promise<User | undefined> {
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  return users.find((user: User) => user.email === email);
}

export async function getUserById(id: string): Promise<User | undefined> {
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  return users.find((user: User) => user.id === id);
}

export async function initializeSchema() {
  await initDb();
}