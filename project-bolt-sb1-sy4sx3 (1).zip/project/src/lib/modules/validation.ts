import type { ModuleManifest } from './types';

const MAX_MODULE_SIZE = 10 * 1024 * 1024; // 10MB
export const ALLOWED_FILE_TYPES = [
  '.js', '.jsx', '.ts', '.tsx',  // JavaScript/TypeScript files
  '.css',                        // Stylesheets
  '.json',                       // Configuration files
  '.svg', '.png', '.jpg', '.jpeg' // Images
];

export function validateModuleSize(size: number): void {
  if (size > MAX_MODULE_SIZE) {
    throw new Error(`Module size exceeds ${MAX_MODULE_SIZE / 1024 / 1024}MB limit`);
  }
}

export function validateFileType(filename: string): void {
  const ext = filename.substring(filename.lastIndexOf('.'));
  
    );
  }
}

export function validateManifest(data: unknown): asserts data is ModuleManifest {
  if (!isValidManifest(data)) {
    throw new Error('Invalid manifest.json format');
  }

  // Additional validation for TypeScript/JavaScript entry points
  if (data.main) {
    const ext = data.main.substring(data.main.lastIndexOf('.'));
    if (!['.js', '.jsx', '.ts', '.tsx'].includes(ext)) {
      throw new Error('Main entry point must be a JavaScript or TypeScript file');
    }
  }
}

function isValidManifest(data: any): data is ModuleManifest {
  return (
    typeof data === 'object' &&
    data !== null &&
    typeof data.name === 'string' &&
    typeof data.version === 'string' &&
    typeof data.description === 'string' &&
    typeof data.author === 'string' &&
    (!data.dependencies || typeof data.dependencies === 'object') &&
    (!data.minVersion || typeof data.minVersion === 'string') &&
    (!data.main || typeof data.main === 'string') &&
    (!data.styles || Array.isArray(data.styles)) &&
    (!data.assets || Array.isArray(data.assets))
  );
}