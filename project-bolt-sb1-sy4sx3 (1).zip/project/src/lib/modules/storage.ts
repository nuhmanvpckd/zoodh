import type { Module } from './types';

const MODULES_STORAGE_KEY = 'social_media_modules';

export function getInstalledModules(): Module[] {
  const modules = localStorage.getItem(MODULES_STORAGE_KEY);
  return modules ? JSON.parse(modules) : [];
}

export function saveModule(module: Module): void {
  const modules = getInstalledModules();
  const existingIndex = modules.findIndex(m => m.id === module.id);
  
  if (existingIndex !== -1) {
    modules[existingIndex] = module;
  } else {
    modules.push(module);
  }
  
  localStorage.setItem(MODULES_STORAGE_KEY, JSON.stringify(modules));
}

export function removeModule(moduleId: string): void {
  const modules = getInstalledModules();
  const filteredModules = modules.filter(m => m.id !== moduleId);
  localStorage.setItem(MODULES_STORAGE_KEY, JSON.stringify(filteredModules));
}