export interface Module {
  id: string;
  name: string;
  version: string;
  description: string;
  author: string;
  files: ModuleFile[];
  installedAt?: string;
  status: 'active' | 'inactive';
  size?: number;
  dependencies?: Record<string, string>;
  minVersion?: string;
}

export interface ModuleFile {
  name: string;
  content: string;
  type: string;
  path: string;
}

export interface ModuleManifest {
  name: string;
  version: string;
  description: string;
  author: string;
  dependencies?: Record<string, string>;
  minVersion?: string;
  main?: string;
  styles?: string[];
  assets?: string[];
}