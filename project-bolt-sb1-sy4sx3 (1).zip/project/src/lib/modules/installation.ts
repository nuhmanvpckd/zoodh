import JSZip from 'jszip';
import { generateId } from '../utils';
import { validateModuleSize, validateFileType, validateManifest } from './validation';
import { getInstalledModules, saveModule } from './storage';
import type { Module, ModuleFile } from './types';

export async function installModule(moduleFile: File): Promise<Module> {
  validateModuleSize(moduleFile.size);

  if (!moduleFile.name.endsWith('.zip')) {
    throw new Error('Module must be a ZIP file');
  }

  try {
    const zip = new JSZip();
    const zipContent = await zip.loadAsync(moduleFile);
    
    // Check and parse manifest
    const manifest = await extractManifest(zipContent);
    
    // Extract files
    const files = await extractFiles(zipContent);

    // Create module object
    const newModule: Module = {
      ...manifest,
      id: generateId(),
      files,
      installedAt: new Date().toISOString(),
      status: 'inactive',
      size: moduleFile.size
    };

    // Check for duplicates
    const modules = getInstalledModules();
    if (modules.some(m => m.name === newModule.name && m.version === newModule.version)) {
      throw new Error('Module already installed');
    }

    // Save module
    saveModule(newModule);
    
    return newModule;
  } catch (error) {
    throw error instanceof Error ? error : new Error('Failed to install module');
  }
}

async function extractManifest(zip: JSZip): Promise<any> {
  const manifestFile = zip.file('manifest.json');
  if (!manifestFile) {
    throw new Error('Missing manifest.json in module package');
  }

  const manifestContent = await manifestFile.async('string');
  const manifest = JSON.parse(manifestContent);
  validateManifest(manifest);

  return manifest;
}

async function extractFiles(zip: JSZip): Promise<ModuleFile[]> {
  const files: ModuleFile[] = [];
  
  for (const [path, file] of Object.entries(zip.files)) {
    if (!file.dir) {
      validateFileType(path);
      
      const content = await file.async('string');
      const ext = path.substring(path.lastIndexOf('.') + 1);
      
      files.push({
        name: path.split('/').pop() || path,
        content,
        type: ext,
        path
      });
    }
  }

  return files;
}

export function activateModule(moduleId: string): void {
  const modules = getInstalledModules();
  const module = modules.find(m => m.id === moduleId);
  
  if (!module) {
    throw new Error('Module not found');
  }

  // Load JavaScript/TypeScript files
  module.files
    .filter(file => ['js', 'jsx', 'ts', 'tsx'].includes(file.type))
    .forEach(file => {
      const script = document.createElement('script');
      script.id = `module-${moduleId}-${file.name}`;
      script.type = 'module';
      script.textContent = file.content;
      document.head.appendChild(script);
    });

  // Load CSS files
  module.files
    .filter(file => file.type === 'css')
    .forEach(file => {
      const style = document.createElement('style');
      style.id = `module-${moduleId}-${file.name}`;
      style.textContent = file.content;
      document.head.appendChild(style);
    });

  module.status = 'active';
  saveModule(module);
}

export function deactivateModule(moduleId: string): void {
  const modules = getInstalledModules();
  const module = modules.find(m => m.id === moduleId);
  
  if (!module) {
    throw new Error('Module not found');
  }

  // Remove JavaScript/TypeScript and CSS elements
  module.files
    .filter(file => ['js', 'jsx', 'ts', 'tsx', 'css'].includes(file.type))
    .forEach(file => {
      const element = document.getElementById(`module-${moduleId}-${file.name}`);
      if (element) {
        element.remove();
      }
    });

  module.status = 'inactive';
  saveModule(module);
}