import { db } from './config';
import type { CreateUserData } from './types';

export function createUser(user: CreateUserData) {
  const stmt = db.prepare(`
    INSERT INTO users (id, email, password, name, role, avatar)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  
  return stmt.run(
    user.id,
    user.email,
    user.password,
    user.name,
    user.role || 'user',
    user.avatar
  );
}

export function getUserByEmail(email: string) {
  const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
  return stmt.get(email);
}

export function getUserById(id: string) {
  const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
  return stmt.get(id);
}