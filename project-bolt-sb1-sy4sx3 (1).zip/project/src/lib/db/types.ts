export interface CreateUserData {
  id: string;
  email: string;
  password: string;
  name: string;
  role?: string;
  avatar?: string;
}