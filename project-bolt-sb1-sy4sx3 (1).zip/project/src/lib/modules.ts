import { generateId } from './utils';
import JSZip from 'jszip';

export interface Module {
  id: string;
  name: string;
  version: string;
  description: string;
  author: string;
  files: ModuleFile[];
  installedAt?: string;
  status: 'active' | 'inactive';
  size?: number;
  dependencies?: Record<string, string>;
  minVersion?: string;
}

interface ModuleFile {
  name: string;
  content: string;
  type: string;
}

const MODULES_STORAGE_KEY = 'social_media_modules';
const MAX_MODULE_SIZE = 10 * 1024 * 1024; // 10MB
const ALLOWED_FILE_TYPES = ['.js', '.css', '.json', '.svg', '.png', '.jpg', '.jpeg'];

export function getInstalledModules(): Module[] {
  const modules = localStorage.getItem(MODULES_STORAGE_KEY);
  return modules ? JSON.parse(modules) : [];
}

export async function installModule(moduleFile: File): Promise<Module> {
  if (moduleFile.size > MAX_MODULE_SIZE) {
    throw new Error('Module size exceeds 10MB limit');
  }

  if (!moduleFile.name.endsWith('.zip')) {
    throw new Error('Module must be a ZIP file');
  }

  try {
    const zip = new JSZip();
    const zipContent = await zip.loadAsync(moduleFile);
    
    // Check for manifest.json
    const manifestFile = zipContent.file('manifest.json');
    if (!manifestFile) {
      throw new Error('Missing manifest.json in module package');
    }

    // Parse manifest
    const manifestContent = await manifestFile.async('string');
    const manifest = JSON.parse(manifestContent);

    if (!isValidManifest(manifest)) {
      throw new Error('Invalid manifest.json format');
    }

    // Extract and validate files
    const files: ModuleFile[] = [];
    for (const [path, file] of Object.entries(zipContent.files)) {
      if (!file.dir) {
        const ext = path.substring(path.lastIndexOf('.'));
        if (!ALLOWED_FILE_TYPES.includes(ext)) {
          throw new Error(`Unsupported file type: ${ext}`);
        }

        const content = await file.async('string');
        files.push({
          name: path,
          content,
          type: ext.substring(1)
        });
      }
    }

    const newModule: Module = {
      ...manifest,
      id: generateId(),
      files,
      installedAt: new Date().toISOString(),
      status: 'inactive',
      size: moduleFile.size
    };

    const modules = getInstalledModules();
    
    // Check for duplicate modules
    if (modules.some(m => m.name === newModule.name && m.version === newModule.version)) {
      throw new Error('Module already installed');
    }

    modules.push(newModule);
    localStorage.setItem(MODULES_STORAGE_KEY, JSON.stringify(modules));
    
    return newModule;
  } catch (error) {
    throw error instanceof Error ? error : new Error('Failed to install module');
  }
}

export function toggleModuleStatus(moduleId: string): Module {
  const modules = getInstalledModules();
  const moduleIndex = modules.findIndex(m => m.id === moduleId);
  
  if (moduleIndex === -1) {
    throw new Error('Module not found');
  }

  modules[moduleIndex].status = modules[moduleIndex].status === 'active' ? 'inactive' : 'active';
  localStorage.setItem(MODULES_STORAGE_KEY, JSON.stringify(modules));
  
  return modules[moduleIndex];
}

export function uninstallModule(moduleId: string): void {
  const modules = getInstalledModules();
  const filteredModules = modules.filter(m => m.id !== moduleId);
  localStorage.setItem(MODULES_STORAGE_KEY, JSON.stringify(filteredModules));
}

function isValidManifest(data: any): boolean {
  return (
    typeof data === 'object' &&
    typeof data.name === 'string' &&
    typeof data.version === 'string' &&
    typeof data.description === 'string' &&
    typeof data.author === 'string' &&
    (!data.dependencies || typeof data.dependencies === 'object') &&
    (!data.minVersion || typeof data.minVersion === 'string')
  );
}